package com.fzucai.yunsign.repository;

import com.fzucai.yunsign.entity.Power;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PowerRepository extends JpaRepository<Power, Integer> {

}
