package com.fzucai.yunsign.repository;

import com.fzucai.yunsign.entity.School;
import com.fzucai.yunsign.entity.Zhuanye;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ZhuanyeRepository extends JpaRepository<Zhuanye,Integer> {
}
