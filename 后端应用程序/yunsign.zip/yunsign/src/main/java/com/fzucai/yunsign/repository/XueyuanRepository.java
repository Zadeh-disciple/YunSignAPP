package com.fzucai.yunsign.repository;

import com.fzucai.yunsign.entity.School;
import com.fzucai.yunsign.entity.Xueyuan;
import org.springframework.data.jpa.repository.JpaRepository;

public interface XueyuanRepository extends JpaRepository<Xueyuan,Integer> {
}
