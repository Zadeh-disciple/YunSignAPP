package com.fzucai.yunsign.repository;

import com.fzucai.yunsign.entity.School;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SchoolRepository extends JpaRepository<School,Integer> {
}
