package com.fzucai.yunsign.controller;


import com.fzucai.yunsign.entity.School;
import com.fzucai.yunsign.repository.SchoolRepository;
import com.fzucai.yunsign.service.SchoolService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/school")
public class SchoolHandler {
    @Autowired
    SchoolService schoolService;

    @GetMapping("/findAll")
    public List<School> findAll(){return schoolService.findAll();}
}
