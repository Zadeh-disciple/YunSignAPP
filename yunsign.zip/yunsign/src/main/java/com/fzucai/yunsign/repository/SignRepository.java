package com.fzucai.yunsign.repository;

import com.fzucai.yunsign.entity.Sign;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SignRepository extends JpaRepository<Sign, Integer> {

}
